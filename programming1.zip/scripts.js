document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('registrationForm');
    const userTableBody = document.querySelector('#userTable tbody');

    loadUsersFromLocalStorage();

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const age = parseInt(document.getElementById('age').value, 10);

        if (age >= 18) {
            const user = {firstName, lastName, age};
            addUserToTable(user);
            saveUserToLocalStorage(user);
            form.reset();
        } else {
            alert('Oups!You have to be over 18 years old.');
        }
    });

    function addUserToTable(user) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${user.firstName}</td>
            <td>${user.lastName}</td>
            <td>${user.age}</td>
        `;
        userTableBody.appendChild(row);
    }

    function saveUserToLocalStorage(user) {
        const users = JSON.parse(localStorage.getItem('users')) || [];
        users.push(user);
        localStorage.setItem('users', JSON.stringify(users));
    }

    function loadUsersFromLocalStorage() {
        const users = JSON.parse(localStorage.getItem('users')) || [];
        users.forEach(user => addUserToTable(user));
    }
});